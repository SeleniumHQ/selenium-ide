# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [3.7.4](https://github.com/SeleniumHQ/selenium-ide/compare/v3.7.3...v3.7.4) (2019-05-16)

**Note:** Version bump only for package selenium-ide-extension
