# Selenium IDE
Read the main README [here](/README.md)
