;(function() {
  var n = /((?:\((?:\([^()]+\)|[^()]+)+\)|\[(?:\[[^\[\]]*\]|['"][^'"]*['"]|[^\[\]'"]+)+\]|\\.|[^ >+~,(\[\\]+)+|[>+~])(\s*,\s*)?((?:.|\r|\n)*)/g,
    i = 'sizcache' + (Math.random() + '').replace('.', ''),
    o = 0,
    r = Object.prototype.toString,
    h = false,
    g = true,
    q = /\\/g,
    u = /\r\n/g,
    w = /\W/
  ;[0, 0].sort(function() {
    g = false
    return 0
  })
  var d = function(B, e, E, F) {
    E = E || []
    e = e || document
    var H = e
    if (e.nodeType !== 1 && e.nodeType !== 9) {
      return []
    }
    if (!B || typeof B !== 'string') {
      return E
    }
    var y,
      J,
      M,
      x,
      I,
      L,
      K,
      D,
      A = true,
      z = d.isXML(e),
      C = [],
      G = B
    do {
      n.exec('')
      y = n.exec(G)
      if (y) {
        G = y[3]
        C.push(y[1])
        if (y[2]) {
          x = y[3]
          break
        }
      }
    } while (y)
    if (C.length > 1 && j.exec(B)) {
      if (C.length === 2 && k.relative[C[0]]) {
        J = s(C[0] + C[1], e, F)
      } else {
        J = k.relative[C[0]] ? [e] : d(C.shift(), e)
        while (C.length) {
          B = C.shift()
          if (k.relative[B]) {
            B += C.shift()
          }
          J = s(B, J, F)
        }
      }
    } else {
      if (
        !F &&
        C.length > 1 &&
        e.nodeType === 9 &&
        !z &&
        k.match.ID.test(C[0]) &&
        !k.match.ID.test(C[C.length - 1])
      ) {
        I = d.find(C.shift(), e, z)
        e = I.expr ? d.filter(I.expr, I.set)[0] : I.set[0]
      }
      if (e) {
        I = F
          ? { expr: C.pop(), set: l(F) }
          : d.find(
              C.pop(),
              C.length === 1 && (C[0] === '~' || C[0] === '+') && e.parentNode
                ? e.parentNode
                : e,
              z
            )
        J = I.expr ? d.filter(I.expr, I.set) : I.set
        if (C.length > 0) {
          M = l(J)
        } else {
          A = false
        }
        while (C.length) {
          L = C.pop()
          K = L
          if (!k.relative[L]) {
            L = ''
          } else {
            K = C.pop()
          }
          if (K == null) {
            K = e
          }
          k.relative[L](M, K, z)
        }
      } else {
        M = C = []
      }
    }
    if (!M) {
      M = J
    }
    if (!M) {
      d.error(L || B)
    }
    if (r.call(M) === '[object Array]') {
      if (!A) {
        E.push.apply(E, M)
      } else {
        if (e && e.nodeType === 1) {
          for (D = 0; M[D] != null; D++) {
            if (
              M[D] &&
              (M[D] === true || (M[D].nodeType === 1 && d.contains(e, M[D])))
            ) {
              E.push(J[D])
            }
          }
        } else {
          for (D = 0; M[D] != null; D++) {
            if (M[D] && M[D].nodeType === 1) {
              E.push(J[D])
            }
          }
        }
      }
    } else {
      l(M, E)
    }
    if (x) {
      d(x, H, E, F)
      d.uniqueSort(E)
    }
    return E
  }
  d.uniqueSort = function(x) {
    if (p) {
      h = g
      x.sort(p)
      if (h) {
        for (var e = 1; e < x.length; e++) {
          if (x[e] === x[e - 1]) {
            x.splice(e--, 1)
          }
        }
      }
    }
    return x
  }
  d.matches = function(e, x) {
    return d(e, null, null, x)
  }
  d.matchesSelector = function(e, x) {
    return d(x, null, null, [e]).length > 0
  }
  d.find = function(D, e, E) {
    var C, y, A, z, B, x
    if (!D) {
      return []
    }
    for (y = 0, A = k.order.length; y < A; y++) {
      B = k.order[y]
      if ((z = k.leftMatch[B].exec(D))) {
        x = z[1]
        z.splice(1, 1)
        if (x.substr(x.length - 1) !== '\\') {
          z[1] = (z[1] || '').replace(q, '')
          C = k.find[B](z, e, E)
          if (C != null) {
            D = D.replace(k.match[B], '')
            break
          }
        }
      }
    }
    if (!C) {
      C =
        typeof e.getElementsByTagName !== 'undefined'
          ? e.getElementsByTagName('*')
          : []
    }
    return { set: C, expr: D }
  }
  d.filter = function(H, G, K, A) {
    var C,
      e,
      F,
      M,
      J,
      x,
      z,
      B,
      I,
      y = H,
      L = [],
      E = G,
      D = G && G[0] && d.isXML(G[0])
    while (H && G.length) {
      for (F in k.filter) {
        if ((C = k.leftMatch[F].exec(H)) != null && C[2]) {
          x = k.filter[F]
          z = C[1]
          e = false
          C.splice(1, 1)
          if (z.substr(z.length - 1) === '\\') {
            continue
          }
          if (E === L) {
            L = []
          }
          if (k.preFilter[F]) {
            C = k.preFilter[F](C, E, K, L, A, D)
            if (!C) {
              e = M = true
            } else {
              if (C === true) {
                continue
              }
            }
          }
          if (C) {
            for (B = 0; (J = E[B]) != null; B++) {
              if (J) {
                M = x(J, C, B, E)
                I = A ^ M
                if (K && M != null) {
                  if (I) {
                    e = true
                  } else {
                    E[B] = false
                  }
                } else {
                  if (I) {
                    L.push(J)
                    e = true
                  }
                }
              }
            }
          }
          if (M !== undefined) {
            if (!K) {
              E = L
            }
            H = H.replace(k.match[F], '')
            if (!e) {
              return []
            }
            break
          }
        }
      }
      if (H === y) {
        if (e == null) {
          d.error(H)
        } else {
          break
        }
      }
      y = H
    }
    return E
  }
  d.error = function(e) {
    throw new Error('Syntax error, unrecognized expression: ' + e)
  }
  var b = (d.getText = function(A) {
    var y,
      z,
      e = A.nodeType,
      x = ''
    if (e) {
      if (e === 1 || e === 9) {
        if (typeof A.textContent === 'string') {
          return A.textContent
        } else {
          if (typeof A.innerText === 'string') {
            return A.innerText.replace(u, '')
          } else {
            for (A = A.firstChild; A; A = A.nextSibling) {
              x += b(A)
            }
          }
        }
      } else {
        if (e === 3 || e === 4) {
          return A.nodeValue
        }
      }
    } else {
      for (y = 0; (z = A[y]); y++) {
        if (z.nodeType !== 8) {
          x += b(z)
        }
      }
    }
    return x
  })
  var k = (d.selectors = {
    order: ['ID', 'NAME', 'TAG'],
    match: {
      ID: /#((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
      CLASS: /\.((?:[\w\u00c0-\uFFFF\-]|\\.)+)/,
      NAME: /\[name=['"]*((?:[\w\u00c0-\uFFFF\-]|\\.)+)['"]*\]/,
      ATTR: /\[\s*((?:[\w\u00c0-\uFFFF\-]|\\.)+)\s*(?:(\S?=)\s*(?:(['"])(.*?)\3|(#?(?:[\w\u00c0-\uFFFF\-]|\\.)*)|)|)\s*\]/,
      TAG: /^((?:[\w\u00c0-\uFFFF\*\-]|\\.)+)/,
      CHILD: /:(only|nth|last|first)-child(?:\(\s*(even|odd|(?:[+\-]?\d+|(?:[+\-]?\d*)?n\s*(?:[+\-]\s*\d+)?))\s*\))?/,
      POS: /:(nth|eq|gt|lt|first|last|even|odd)(?:\((\d*)\))?(?=[^\-]|$)/,
      PSEUDO: /:((?:[\w\u00c0-\uFFFF\-]|\\.)+)(?:\((['"]?)((?:\([^\)]+\)|[^\(\)]*)+)\2\))?/,
    },
    leftMatch: {},
    attrMap: { class: 'className', for: 'htmlFor' },
    attrHandle: {
      href: function(e) {
        return e.getAttribute('href')
      },
      type: function(e) {
        return e.getAttribute('type')
      },
    },
    relative: {
      '+': function(C, x) {
        var z = typeof x === 'string',
          B = z && !w.test(x),
          D = z && !B
        if (B) {
          x = x.toLowerCase()
        }
        for (var y = 0, e = C.length, A; y < e; y++) {
          if ((A = C[y])) {
            while ((A = A.previousSibling) && A.nodeType !== 1) {}
            C[y] =
              D || (A && A.nodeName.toLowerCase() === x) ? A || false : A === x
          }
        }
        if (D) {
          d.filter(x, C, true)
        }
      },
      '>': function(C, x) {
        var B,
          A = typeof x === 'string',
          y = 0,
          e = C.length
        if (A && !w.test(x)) {
          x = x.toLowerCase()
          for (; y < e; y++) {
            B = C[y]
            if (B) {
              var z = B.parentNode
              C[y] = z.nodeName.toLowerCase() === x ? z : false
            }
          }
        } else {
          for (; y < e; y++) {
            B = C[y]
            if (B) {
              C[y] = A ? B.parentNode : B.parentNode === x
            }
          }
          if (A) {
            d.filter(x, C, true)
          }
        }
      },
      '': function(z, x, B) {
        var A,
          y = o++,
          e = t
        if (typeof x === 'string' && !w.test(x)) {
          x = x.toLowerCase()
          A = x
          e = a
        }
        e('parentNode', x, y, z, A, B)
      },
      '~': function(z, x, B) {
        var A,
          y = o++,
          e = t
        if (typeof x === 'string' && !w.test(x)) {
          x = x.toLowerCase()
          A = x
          e = a
        }
        e('previousSibling', x, y, z, A, B)
      },
    },
    find: {
      ID: function(x, y, z) {
        if (typeof y.getElementById !== 'undefined' && !z) {
          var e = y.getElementById(x[1])
          return e && e.parentNode ? [e] : []
        }
      },
      NAME: function(y, B) {
        if (typeof B.getElementsByName !== 'undefined') {
          var x = [],
            A = B.getElementsByName(y[1])
          for (var z = 0, e = A.length; z < e; z++) {
            if (A[z].getAttribute('name') === y[1]) {
              x.push(A[z])
            }
          }
          return x.length === 0 ? null : x
        }
      },
      TAG: function(e, x) {
        if (typeof x.getElementsByTagName !== 'undefined') {
          return x.getElementsByTagName(e[1])
        }
      },
    },
    preFilter: {
      CLASS: function(z, x, y, e, C, D) {
        z = ' ' + z[1].replace(q, '') + ' '
        if (D) {
          return z
        }
        for (var A = 0, B; (B = x[A]) != null; A++) {
          if (B) {
            if (
              C ^
              (B.className &&
                (' ' + B.className + ' ')
                  .replace(/[\t\n\r]/g, ' ')
                  .indexOf(z) >= 0)
            ) {
              if (!y) {
                e.push(B)
              }
            } else {
              if (y) {
                x[A] = false
              }
            }
          }
        }
        return false
      },
      ID: function(e) {
        return e[1].replace(q, '')
      },
      TAG: function(x, e) {
        return x[1].replace(q, '').toLowerCase()
      },
      CHILD: function(e) {
        if (e[1] === 'nth') {
          if (!e[2]) {
            d.error(e[0])
          }
          e[2] = e[2].replace(/^\+|\s*/g, '')
          var x = /(-?)(\d*)(?:n([+\-]?\d*))?/.exec(
            (e[2] === 'even' && '2n') ||
              (e[2] === 'odd' && '2n+1') ||
              (!/\D/.test(e[2]) && '0n+' + e[2]) ||
              e[2]
          )
          e[2] = x[1] + (x[2] || 1) - 0
          e[3] = x[3] - 0
        } else {
          if (e[2]) {
            d.error(e[0])
          }
        }
        e[0] = o++
        return e
      },
      ATTR: function(A, x, y, e, B, C) {
        var z = (A[1] = A[1].replace(q, ''))
        if (!C && k.attrMap[z]) {
          A[1] = k.attrMap[z]
        }
        A[4] = (A[4] || A[5] || '').replace(q, '')
        if (A[2] === '~=') {
          A[4] = ' ' + A[4] + ' '
        }
        return A
      },
      PSEUDO: function(A, x, y, e, B) {
        if (A[1] === 'not') {
          if ((n.exec(A[3]) || '').length > 1 || /^\w/.test(A[3])) {
            A[3] = d(A[3], null, null, x)
          } else {
            var z = d.filter(A[3], x, y, true ^ B)
            if (!y) {
              e.push.apply(e, z)
            }
            return false
          }
        } else {
          if (k.match.POS.test(A[0]) || k.match.CHILD.test(A[0])) {
            return true
          }
        }
        return A
      },
      POS: function(e) {
        e.unshift(true)
        return e
      },
    },
    filters: {
      enabled: function(e) {
        return e.disabled === false && e.type !== 'hidden'
      },
      disabled: function(e) {
        return e.disabled === true
      },
      checked: function(e) {
        return e.checked === true
      },
      selected: function(e) {
        if (e.parentNode) {
          e.parentNode.selectedIndex
        }
        return e.selected === true
      },
      parent: function(e) {
        return !!e.firstChild
      },
      empty: function(e) {
        return !e.firstChild
      },
      has: function(y, x, e) {
        return !!d(e[3], y).length
      },
      header: function(e) {
        return /h\d/i.test(e.nodeName)
      },
      text: function(y) {
        var e = y.getAttribute('type'),
          x = y.type
        return (
          y.nodeName.toLowerCase() === 'input' &&
          'text' === x &&
          (e === x || e === null)
        )
      },
      radio: function(e) {
        return e.nodeName.toLowerCase() === 'input' && 'radio' === e.type
      },
      checkbox: function(e) {
        return e.nodeName.toLowerCase() === 'input' && 'checkbox' === e.type
      },
      file: function(e) {
        return e.nodeName.toLowerCase() === 'input' && 'file' === e.type
      },
      password: function(e) {
        return e.nodeName.toLowerCase() === 'input' && 'password' === e.type
      },
      submit: function(x) {
        var e = x.nodeName.toLowerCase()
        return (e === 'input' || e === 'button') && 'submit' === x.type
      },
      image: function(e) {
        return e.nodeName.toLowerCase() === 'input' && 'image' === e.type
      },
      reset: function(x) {
        var e = x.nodeName.toLowerCase()
        return (e === 'input' || e === 'button') && 'reset' === x.type
      },
      button: function(x) {
        var e = x.nodeName.toLowerCase()
        return (e === 'input' && 'button' === x.type) || e === 'button'
      },
      input: function(e) {
        return /input|select|textarea|button/i.test(e.nodeName)
      },
      focus: function(e) {
        return e === e.ownerDocument.activeElement
      },
    },
    setFilters: {
      first: function(x, e) {
        return e === 0
      },
      last: function(y, x, e, z) {
        return x === z.length - 1
      },
      even: function(x, e) {
        return e % 2 === 0
      },
      odd: function(x, e) {
        return e % 2 === 1
      },
      lt: function(y, x, e) {
        return x < e[3] - 0
      },
      gt: function(y, x, e) {
        return x > e[3] - 0
      },
      nth: function(y, x, e) {
        return e[3] - 0 === x
      },
      eq: function(y, x, e) {
        return e[3] - 0 === x
      },
    },
    filter: {
      PSEUDO: function(y, D, C, E) {
        var e = D[1],
          x = k.filters[e]
        if (x) {
          return x(y, C, D, E)
        } else {
          if (e === 'contains') {
            return (
              (y.textContent || y.innerText || b([y]) || '').indexOf(D[3]) >= 0
            )
          } else {
            if (e === 'not') {
              var z = D[3]
              for (var B = 0, A = z.length; B < A; B++) {
                if (z[B] === y) {
                  return false
                }
              }
              return true
            } else {
              d.error(e)
            }
          }
        }
      },
      CHILD: function(y, A) {
        var z,
          G,
          C,
          F,
          e,
          B,
          E,
          D = A[1],
          x = y
        switch (D) {
          case 'only':
          case 'first':
            while ((x = x.previousSibling)) {
              if (x.nodeType === 1) {
                return false
              }
            }
            if (D === 'first') {
              return true
            }
            x = y
          case 'last':
            while ((x = x.nextSibling)) {
              if (x.nodeType === 1) {
                return false
              }
            }
            return true
          case 'nth':
            z = A[2]
            G = A[3]
            if (z === 1 && G === 0) {
              return true
            }
            C = A[0]
            F = y.parentNode
            if (F && (F[i] !== C || !y.nodeIndex)) {
              B = 0
              for (x = F.firstChild; x; x = x.nextSibling) {
                if (x.nodeType === 1) {
                  x.nodeIndex = ++B
                }
              }
              F[i] = C
            }
            E = y.nodeIndex - G
            if (z === 0) {
              return E === 0
            } else {
              return E % z === 0 && E / z >= 0
            }
        }
      },
      ID: function(x, e) {
        return x.nodeType === 1 && x.getAttribute('id') === e
      },
      TAG: function(x, e) {
        return (
          (e === '*' && x.nodeType === 1) ||
          (!!x.nodeName && x.nodeName.toLowerCase() === e)
        )
      },
      CLASS: function(x, e) {
        return (
          (' ' + (x.className || x.getAttribute('class')) + ' ').indexOf(e) > -1
        )
      },
      ATTR: function(B, z) {
        var y = z[1],
          e = d.attr
            ? d.attr(B, y)
            : k.attrHandle[y]
            ? k.attrHandle[y](B)
            : B[y] != null
            ? B[y]
            : B.getAttribute(y),
          C = e + '',
          A = z[2],
          x = z[4]
        return e == null
          ? A === '!='
          : !A && d.attr
          ? e != null
          : A === '='
          ? C === x
          : A === '*='
          ? C.indexOf(x) >= 0
          : A === '~='
          ? (' ' + C + ' ').indexOf(x) >= 0
          : !x
          ? C && e !== false
          : A === '!='
          ? C !== x
          : A === '^='
          ? C.indexOf(x) === 0
          : A === '$='
          ? C.substr(C.length - x.length) === x
          : A === '|='
          ? C === x || C.substr(0, x.length + 1) === x + '-'
          : false
      },
      POS: function(A, x, y, B) {
        var e = x[2],
          z = k.setFilters[e]
        if (z) {
          return z(A, y, x, B)
        }
      },
    },
  })
  var j = k.match.POS,
    c = function(x, e) {
      return '\\' + (e - 0 + 1)
    }
  for (var f in k.match) {
    k.match[f] = new RegExp(
      k.match[f].source + /(?![^\[]*\])(?![^\(]*\))/.source
    )
    k.leftMatch[f] = new RegExp(
      /(^(?:.|\r|\n)*?)/.source + k.match[f].source.replace(/\\(\d+)/g, c)
    )
  }
  k.match.globalPOS = j
  var l = function(x, e) {
    x = Array.prototype.slice.call(x, 0)
    if (e) {
      e.push.apply(e, x)
      return e
    }
    return x
  }
  try {
    Array.prototype.slice.call(document.documentElement.childNodes, 0)[0]
      .nodeType
  } catch (v) {
    l = function(A, z) {
      var y = 0,
        x = z || []
      if (r.call(A) === '[object Array]') {
        Array.prototype.push.apply(x, A)
      } else {
        if (typeof A.length === 'number') {
          for (var e = A.length; y < e; y++) {
            x.push(A[y])
          }
        } else {
          for (; A[y]; y++) {
            x.push(A[y])
          }
        }
      }
      return x
    }
  }
  var p, m
  if (document.documentElement.compareDocumentPosition) {
    p = function(x, e) {
      if (x === e) {
        h = true
        return 0
      }
      if (!x.compareDocumentPosition || !e.compareDocumentPosition) {
        return x.compareDocumentPosition ? -1 : 1
      }
      return x.compareDocumentPosition(e) & 4 ? -1 : 1
    }
  } else {
    p = function(E, D) {
      if (E === D) {
        h = true
        return 0
      } else {
        if (E.sourceIndex && D.sourceIndex) {
          return E.sourceIndex - D.sourceIndex
        }
      }
      var B,
        x,
        y = [],
        e = [],
        A = E.parentNode,
        C = D.parentNode,
        F = A
      if (A === C) {
        return m(E, D)
      } else {
        if (!A) {
          return -1
        } else {
          if (!C) {
            return 1
          }
        }
      }
      while (F) {
        y.unshift(F)
        F = F.parentNode
      }
      F = C
      while (F) {
        e.unshift(F)
        F = F.parentNode
      }
      B = y.length
      x = e.length
      for (var z = 0; z < B && z < x; z++) {
        if (y[z] !== e[z]) {
          return m(y[z], e[z])
        }
      }
      return z === B ? m(E, e[z], -1) : m(y[z], D, 1)
    }
    m = function(x, e, y) {
      if (x === e) {
        return y
      }
      var z = x.nextSibling
      while (z) {
        if (z === e) {
          return -1
        }
        z = z.nextSibling
      }
      return 1
    }
  }
  ;(function() {
    var x = document.createElement('div'),
      y = 'script' + new Date().getTime(),
      e = document.documentElement
    x.innerHTML = "<a name='" + y + "'/>"
    e.insertBefore(x, e.firstChild)
    if (document.getElementById(y)) {
      k.find.ID = function(A, B, C) {
        if (typeof B.getElementById !== 'undefined' && !C) {
          var z = B.getElementById(A[1])
          return z
            ? z.id === A[1] ||
              (typeof z.getAttributeNode !== 'undefined' &&
                z.getAttributeNode('id').nodeValue === A[1])
              ? [z]
              : undefined
            : []
        }
      }
      k.filter.ID = function(B, z) {
        var A =
          typeof B.getAttributeNode !== 'undefined' && B.getAttributeNode('id')
        return B.nodeType === 1 && A && A.nodeValue === z
      }
    }
    e.removeChild(x)
    e = x = null
  })()
  ;(function() {
    var e = document.createElement('div')
    e.appendChild(document.createComment(''))
    if (e.getElementsByTagName('*').length > 0) {
      k.find.TAG = function(x, B) {
        var A = B.getElementsByTagName(x[1])
        if (x[1] === '*') {
          var z = []
          for (var y = 0; A[y]; y++) {
            if (A[y].nodeType === 1) {
              z.push(A[y])
            }
          }
          A = z
        }
        return A
      }
    }
    e.innerHTML = "<a href='#'></a>"
    if (
      e.firstChild &&
      typeof e.firstChild.getAttribute !== 'undefined' &&
      e.firstChild.getAttribute('href') !== '#'
    ) {
      k.attrHandle.href = function(x) {
        return x.getAttribute('href', 2)
      }
    }
    e = null
  })()
  if (document.querySelectorAll) {
    ;(function() {
      var e = d,
        z = document.createElement('div'),
        y = '__sizzle__'
      z.innerHTML = "<p class='TEST'></p>"
      if (z.querySelectorAll && z.querySelectorAll('.TEST').length === 0) {
        return
      }
      d = function(K, B, F, J) {
        B = B || document
        if (!J && !d.isXML(B)) {
          var I = /^(\w+$)|^\.([\w\-]+$)|^#([\w\-]+$)/.exec(K)
          if (I && (B.nodeType === 1 || B.nodeType === 9)) {
            if (I[1]) {
              return l(B.getElementsByTagName(K), F)
            } else {
              if (I[2] && k.find.CLASS && B.getElementsByClassName) {
                return l(B.getElementsByClassName(I[2]), F)
              }
            }
          }
          if (B.nodeType === 9) {
            if (K === 'body' && B.body) {
              return l([B.body], F)
            } else {
              if (I && I[3]) {
                var E = B.getElementById(I[3])
                if (E && E.parentNode) {
                  if (E.id === I[3]) {
                    return l([E], F)
                  }
                } else {
                  return l([], F)
                }
              }
            }
            try {
              return l(B.querySelectorAll(K), F)
            } catch (G) {}
          } else {
            if (B.nodeType === 1 && B.nodeName.toLowerCase() !== 'object') {
              var C = B,
                D = B.getAttribute('id'),
                A = D || y,
                M = B.parentNode,
                L = /^\s*[+~]/.test(K)
              if (!D) {
                B.setAttribute('id', A)
              } else {
                A = A.replace(/'/g, '\\$&')
              }
              if (L && M) {
                B = B.parentNode
              }
              try {
                if (!L || M) {
                  return l(B.querySelectorAll("[id='" + A + "'] " + K), F)
                }
              } catch (H) {
              } finally {
                if (!D) {
                  C.removeAttribute('id')
                }
              }
            }
          }
        }
        return e(K, B, F, J)
      }
      for (var x in e) {
        d[x] = e[x]
      }
      z = null
    })()
  }
  ;(function() {
    var e = document.documentElement,
      y =
        e.matchesSelector ||
        e.mozMatchesSelector ||
        e.webkitMatchesSelector ||
        e.msMatchesSelector
    if (y) {
      var A = !y.call(document.createElement('div'), 'div'),
        x = false
      try {
        y.call(document.documentElement, "[test!='']:sizzle")
      } catch (z) {
        x = true
      }
      d.matchesSelector = function(C, E) {
        E = E.replace(/\=\s*([^'"\]]*)\s*\]/g, "='$1']")
        if (!d.isXML(C)) {
          try {
            if (x || (!k.match.PSEUDO.test(E) && !/!=/.test(E))) {
              var B = y.call(C, E)
              if (B || !A || (C.document && C.document.nodeType !== 11)) {
                return B
              }
            }
          } catch (D) {}
        }
        return d(E, null, null, [C]).length > 0
      }
    }
  })()
  ;(function() {
    var e = document.createElement('div')
    e.innerHTML = "<div class='test e'></div><div class='test'></div>"
    if (
      !e.getElementsByClassName ||
      e.getElementsByClassName('e').length === 0
    ) {
      return
    }
    e.lastChild.className = 'e'
    if (e.getElementsByClassName('e').length === 1) {
      return
    }
    k.order.splice(1, 0, 'CLASS')
    k.find.CLASS = function(x, y, z) {
      if (typeof y.getElementsByClassName !== 'undefined' && !z) {
        return y.getElementsByClassName(x[1])
      }
    }
    e = null
  })()
  function a(x, C, B, F, D, E) {
    for (var z = 0, y = F.length; z < y; z++) {
      var e = F[z]
      if (e) {
        var A = false
        e = e[x]
        while (e) {
          if (e[i] === B) {
            A = F[e.sizset]
            break
          }
          if (e.nodeType === 1 && !E) {
            e[i] = B
            e.sizset = z
          }
          if (e.nodeName.toLowerCase() === C) {
            A = e
            break
          }
          e = e[x]
        }
        F[z] = A
      }
    }
  }
  function t(x, C, B, F, D, E) {
    for (var z = 0, y = F.length; z < y; z++) {
      var e = F[z]
      if (e) {
        var A = false
        e = e[x]
        while (e) {
          if (e[i] === B) {
            A = F[e.sizset]
            break
          }
          if (e.nodeType === 1) {
            if (!E) {
              e[i] = B
              e.sizset = z
            }
            if (typeof C !== 'string') {
              if (e === C) {
                A = true
                break
              }
            } else {
              if (d.filter(C, [e]).length > 0) {
                A = e
                break
              }
            }
          }
          e = e[x]
        }
        F[z] = A
      }
    }
  }
  if (document.documentElement.contains) {
    d.contains = function(x, e) {
      return x !== e && (x.contains ? x.contains(e) : true)
    }
  } else {
    if (document.documentElement.compareDocumentPosition) {
      d.contains = function(x, e) {
        return !!(x.compareDocumentPosition(e) & 16)
      }
    } else {
      d.contains = function() {
        return false
      }
    }
  }
  d.isXML = function(e) {
    var x = (e ? e.ownerDocument || e : 0).documentElement
    return x ? x.nodeName !== 'HTML' : false
  }
  var s = function(y, e, C) {
    var B,
      D = [],
      A = '',
      E = e.nodeType ? [e] : e
    while ((B = k.match.PSEUDO.exec(y))) {
      A += B[0]
      y = y.replace(k.match.PSEUDO, '')
    }
    y = k.relative[y] ? y + '*' : y
    for (var z = 0, x = E.length; z < x; z++) {
      d(y, E[z], D, C)
    }
    return d.filter(A, D)
  }
  window.Sizzle = d
})()
