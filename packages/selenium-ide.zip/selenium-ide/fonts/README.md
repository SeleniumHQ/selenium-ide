See [the wiki article for details on how to use and update the fonts](https://github.com/SeleniumHQ/selenium-ide/wiki/Adding-New-Icons-as-Fonts-to-the-IDE) for details.
